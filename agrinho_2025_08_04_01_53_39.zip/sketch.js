function setup() {
  createCanvas(800, 600);
  noLoop();
}

function draw() {
  desenharCeu();
  desenharCidade();
  desenharChao();
  desenharMilho();
  desenharSol();
}

// ce
function desenharCeu() {
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let cor = lerpColor  (color("#EEF4F5"),  color("#03A9F4"), inter);
    stroke(cor);
    line(0, y, width, y);
  }
}

// so
function desenharSol() {
  noStroke();
  fill(255, 204, 0, 180);
  ellipse(100, 100, 100);
}

// cdd
function desenharCidade() {
  fill("#000000");
  for (let x = 0; x < width; x += 80) {
    let h = random(100, 250);
    rect(x, height - h - 200, 60, h);
  }
}

// solo
function desenharChao() {
  noStroke(0)
  fill("#73AD2E" );
  rect(0, height - 200, width, 200);
}

// mi
function desenharMilho() {
  for (let x = 40; x < width; x += 60) {
    desenharPlanta(x, height - 160);
  }
}

// pln
function desenharPlanta(x, y) {

 
  line(x, y, x, y + 50); 
  fill(255, 215, 0); 
  ellipse(x, y + 20, 20, 40);

  fill(34, 139, 34); 
  ellipse(x - 10, y + 25, 12, 25);
  ellipse(x + 10, y + 25, 12, 25);
}
