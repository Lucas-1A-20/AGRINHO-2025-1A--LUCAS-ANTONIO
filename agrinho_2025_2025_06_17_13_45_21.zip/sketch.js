function setup() {
  createCanvas(800, 600);
  noLoop();
}

function draw() {
  drawSky();
  drawCitySilhouette(); 
  drawGround();
  drawCornField();      
  drawSun();
}

// Ceu
function drawSky() {
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(color(135, 206, 250), color(100, 149, 237), inter);
    stroke(c);
    line(0, y, width, y);
  }
}

// SOOL
function drawSun() {
  noStroke();
  fill(255, 204, 0, 180);
  ellipse(100, 100, 100);
}

// Cidadeee
function drawCitySilhouette() {
  fill(50, 50, 70);
  for (let x = 0; x < width; x += 80) {
    let h = random(100, 250);
    rect(x, height - h - 200, 60, h);
  }
}

// o chao
function drawGround() {
  noStroke();
  fill(60, 160, 70);
  rect(0, height - 200, width, 200);
}

// Plantação de milhos
function drawCornField() {
  for (let x = 40; x < width; x += 60) {
    drawCorn(x, height - 160);
  }
}

//  milho
function drawCorn(x, y) {
  stroke(90, 120, 40);
  strokeWeight(3);
  line(x, y, x, y + 50); 
  noStroke();
  fill(255, 215, 0); 
  ellipse(x, y + 20, 20, 40);

  fill(34, 139, 34); 
  ellipse(x - 10, y + 25, 12, 25);
  ellipse(x + 10, y + 25, 12, 25);
}
